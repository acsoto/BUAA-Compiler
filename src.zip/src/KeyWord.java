import java.security.Key;

public enum KeyWord {
    MAINT("main", "MAINTK"),
    CONSTTK("const", "CONSTTK"),
    INTTK("int", "INTTK"),
    BREAKTK("break", "BREAKTK"),
    CONTINUETK("continue", "CONTINUETK"),
    IFTK("if", "IFTK"),
    ELSETK("else", "ELSETK"),
    NOT("!", "NOT"),
    AND("&&", "AND"),
    OR("||", "OR"),
    WHILETK("while", "WHILETK"),
    GETINTTK("getint", "GETINTTK"),
    PRINTFTK("printf", "PRINTFTK"),
    RETURNTK("return", "RETURNTK"),
    PLUS("+", "PLUS"),
    MINU("-", "MINU"),
    VOIDTK("void", "VOIDTK"),
    MULT("*", "MULT"),
    DIV("/", "DIV"),
    MOD("%", "MOD"),
    LSS("<", "LSS"),
    LEQ("<=", "LEQ"),
    GRE(">", "GRE"),
    GEQ(">=", "GEQ"),
    EQL("==", "EQL"),
    NEQ("!=", "NEQ"),
    ASSIGN("=", "ASSIGN"),
    SEMICN(";", "SEMICN"),
    COMMA(",", "COMMA"),
    LPARENT("(", "LPARENT"),
    RPARENT(")", "RPARENT"),
    LBRACK("[", "LBRACK"),
    RBRACK("]", "RBRACK"),
    LBRACE("{", "LBRACE"),
    RBRACE("}", "RBRACE");

    private String identification;
    private String name;

    KeyWord(String identification, String name) {
        this.identification = identification;
        this.name = name;
    }
}
